"""W16 (Fixliste 14) Gateway-Observer: Session-Quelle + Sub-Agenten ans Phone.

Beobachtet Gateway-Turns (agent:start/step/end — Kontext: platform,
session_id, chat_id; agent:end zusätzlich model) und laufende
async_delegations-Sub-Agenten aus der State-DB (read-only) und pusht die
Session-Meta an die FlipsiBridge-Phone-Chats via
FlipsiBridgeChatAdapter.push_session_meta(chat_id, platform=..., model=...,
sub_agents=[...]).

Verträge (REPORT-b4_dashboard_agenten.md, Feld-Verträge):
- platform   = Plattform des LAUFENDEN Turns; 'flipsibridge' → 'bridge'
               (Parität zu den Activity-Frames des Adapters).
- model      = agent:end-Kontext-Modell, sonst sessions.model (State-DB);
               Unbekannt = Feld weg (kein Fake-Wert).
- sub_agents = [{name, status, model}] je laufender Delegation dieser
               Session; Batch: ein Eintrag je goal; Status-Text 'läuft'.

Dedup je (agent_id, chat_id): nur bei Änderung pushen; Einträge verfallen
(TTL), damit ein während WS-Toten verlorener Push beim nächsten Event
nachgeholt wird. Fail-soft: ALLE Fehler werden geloggt, nie ein Turn
gebremst. Die Session-DB wird NUR LESEND (mode=ro) geöffnet.

Bekannte Grenze (ehrlich, nicht erfunden): Cron-Turns laufen über
cron/scheduler.run_job (AIAgent direkt), NICHT über den Gateway-Turn-Pfad
— dort feuern KEINE agent:*-Hooks (siehe REPORT). Delegation-Ende wird
beim nächsten Event des Turn-Pfads sichtbar (kein Eigen-Timer).
"""
from __future__ import annotations

import gc
import json
import logging
import os
import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("flipsibridge.meta_hook")

_ADAPTER_CLASS_NAME = "FlipsiBridgeChatAdapter"
_ADAPTER_MODULE_SUFFIX = "flipsibridge_chat.adapter"  # loader: hermes_plugins.<slug>.adapter
_ADAPTER_CACHE_TTL_S = 60.0          # gc-Scan ist teuer — kurz cachen
_DEDUP_TTL_S = 120.0                 # verlorene Pushes nachholen (WS-Tot → Reconnect)
_SUBS_MAX = 8                        # Parität: _SESSION_META_MAX_SUB_AGENTS (Adapter)
_NAME_MAX = 48                       # Anzeige-Kürze für Sub-Agent-Namen (Phone-Zeile)
_STATUS_TEXT = "läuft"               # Gateway-Wortwahl (B4: Phone zeichnet 1:1)
_PLATFORM_BRIDGE_LABEL = "bridge"    # Adapter-Konstante _SESSION_META_PLATFORM_BRIDGE
_MODEL_RE = re.compile(r"^[A-Za-z0-9._:@/+-]{1,64}$")  # Parität _COMPOSER_MODEL_RE

_DEDUP_LOCK = threading.Lock()
_LAST_PUSHED: dict[tuple, tuple] = {}  # (agent_id, chat_id) → (fingerprint, monotonic_ts)
_ADAPTER_CACHE: list = [0.0, []]       # [expires_monotonic, [instanz, ...]]


# ── State-DB (read-only) ─────────────────────────────────────────────────────

def _state_db_path() -> Path:
    """State-DB des aktiven Profils (Handler läuft im Profil-Scope des
    Gateways): hermes_cli.get_hermes_home (in-process) → HERMES_HOME →
    ~/.hermes."""
    try:
        from hermes_cli.config import get_hermes_home  # noqa: PLC0415 (fail-safe)
        return Path(get_hermes_home()) / "state.db"
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
        return Path(home) / "state.db"


def _ro_query(sql: str, params: tuple) -> Optional[list]:
    """Read-only-Query auf die State-DB (mode=ro, 2 s Timeout). None = DB
    nicht lesbar — der Aufrufer lässt den Push dann KOMPLETT weg (kein
    Meta mit erfundenen/leeren Feldern anstoßen)."""
    path = _state_db_path()
    if not path.exists():
        return None
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2.0)
    except Exception:
        return None
    try:
        return conn.execute(sql, params).fetchall()
    except Exception:
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _norm_model(value) -> str:
    """Modell-String säubern; unsaubere Werte = '' (Feld bleibt weg)."""
    text = str(value or "").strip()
    if not text or not _MODEL_RE.match(text):
        return ""
    return text


def _session_row(session_id: str) -> Optional[dict]:
    """sessions-Row der Turn-Session (chat_id, model) — None = nicht lesbar."""
    if not session_id:
        return None
    rows = _ro_query(
        "SELECT chat_id, model FROM sessions WHERE id=?", (session_id,))
    if rows is None:
        return None
    if not rows:
        return {"chat_id": "", "model": ""}  # Session (noch) nicht persistiert
    return {"chat_id": str(rows[0][0] or ""), "model": _norm_model(rows[0][1])}


def _sub_agents(session_id: str) -> Optional[list]:
    """Laufende Sub-Agenten dieser Session aus async_delegations.

    state IN ('running','finalizing') = nicht abgeschlossen → 'läuft'.
    Batch-Delegation (goals-Liste): ein Eintrag je Task. task_json ohne
    lesbaren Namen fliegt (Phone: Name-freie Einträge weg). None = DB-Fehler.
    """
    rows = _ro_query(
        "SELECT state, task_json FROM async_delegations "
        "WHERE parent_session_id=? AND state IN ('running','finalizing') "
        "ORDER BY dispatched_at DESC LIMIT 16", (session_id,))
    if rows is None:
        return None
    subs: list = []
    for _state, task_json in rows:
        try:
            task = json.loads(task_json or "{}")
        except ValueError:
            continue
        if not isinstance(task, dict):
            continue
        model = _norm_model(task.get("model"))
        goals = task.get("goals")
        goal_texts = goals if isinstance(goals, list) and goals else [task.get("goal")]
        for goal_text in goal_texts:
            name = " ".join(str(goal_text or "").split())[:_NAME_MAX].strip()
            if not name:
                continue
            sub: dict = {"name": name, "status": _STATUS_TEXT}
            if model:
                sub["model"] = model
            subs.append(sub)
            if len(subs) >= _SUBS_MAX:
                return subs
    return subs


# ── Adapter-Instanz-Findung (im Gateway-Prozess) ─────────────────────────────

def _adapters() -> list:
    """LIVE-FlipsiBridge-Chats-Adapter-Instanzen. Pfad 1: Loader-Namespace
    (sys.modules, hermes_plugins.<slug>.adapter) → Klasse → WeakSet. Pfad 2
    (Fallback): gc-Klassenscan. Cache 60 s (gc-Scan teuer). Fehler = []."""
    expires, cached = _ADAPTER_CACHE
    now = time.monotonic()
    if now < expires:
        return cached
    found: list = []
    try:
        adapter_cls = None
        for name, module in list(__import__("sys").modules.items()):
            if name.endswith(_ADAPTER_MODULE_SUFFIX) and module is not None:
                candidate = getattr(module, _ADAPTER_CLASS_NAME, None)
                if candidate is not None:
                    adapter_cls = candidate
                    break
        if adapter_cls is not None and hasattr(adapter_cls, "live_instances"):
            found = [inst for inst in adapter_cls.live_instances()
                     if getattr(inst, "is_connected", lambda: False)()]
        if not found:
            # Fallback: gc-Klassenscan (Namespace abweichend, z. B. älteres
            # Layout ohne live_instances-Helfer).
            for obj in gc.get_objects():
                if type(obj).__name__ == _ADAPTER_CLASS_NAME \
                        and getattr(obj, "is_connected", lambda: False)():
                    found.append(obj)
    except Exception:
        found = []
    _ADAPTER_CACHE[0] = now + _ADAPTER_CACHE_TTL_S
    _ADAPTER_CACHE[1] = found
    return found


def _push_targets(adapter) -> list:
    """Wire-Chat-IDs je Instanz: meta_push_targets() wenn vorhanden
    (ab Adapter-Neuladen), sonst Private-Attr-Fallback (read-only) —
    Läuft auch mit der HEUTE laufenden Adapter-Version ohne Helper."""
    try:
        helper = getattr(adapter, "meta_push_targets", None)
        if helper is not None:
            targets = helper()
            return list(targets) if isinstance(targets, list) else []
    except Exception:
        pass
    targets: list = []
    try:  # Fallback (aktive Version): Empfangs-Map + Mapping — Relay-IDs zuerst
        newest = sorted(adapter._received_at.items(), key=lambda kv: kv[1],
                        reverse=True)
        targets = [chat_id for chat_id, _ts in newest]
        for chat_id in adapter._gw_chat_by_relay:
            if chat_id not in targets:
                targets.append(chat_id)
    except Exception:
        targets = targets or []
    return targets


# ── Push-Kern ────────────────────────────────────────────────────────────────

def _meta_payload(platform: str, model: str, subs: Optional[list]) -> dict:
    """Kanonisches Payload (Fingerprint-Basis) — nur BEKANNTE Werte."""
    subs = subs if isinstance(subs, list) else []
    return {
        "platform": platform,
        "model": model,
        "subs": subs,
    }


def _fingerprint(payload: dict) -> str:
    try:
        blob = json.dumps(payload, sort_keys=True, ensure_ascii=False,
                          separators=(",", ":"))
        return blob
    except Exception:
        return ""


async def _observe(event_type: str, context: dict) -> None:
    platform_raw = str(context.get("platform") or "").strip()
    if not platform_raw:
        return
    platform = (_PLATFORM_BRIDGE_LABEL if platform_raw == "flipsibridge"
                else platform_raw)
    session_id = str(context.get("session_id") or "")

    session = _session_row(session_id)
    subs = _sub_agents(session_id)
    if session is None or subs is None:
        logger.debug("flipsi-session-meta: State-DB nicht lesbar — Push übersprungen")
        return
    model = _norm_model(context.get("model")) if event_type == "agent:end" else ""
    if not model:
        model = session.get("model") or ""

    payload = _meta_payload(platform, model, subs)
    fingerprint = _fingerprint(payload)
    if not fingerprint:
        return

    now = time.monotonic()
    with _DEDUP_LOCK:
        dead = [key for key, (_fp, ts) in _LAST_PUSHED.items()
                if now - ts > _DEDUP_TTL_S]
        for key in dead:
            _LAST_PUSHED.pop(key, None)

    for adapter in _adapters():
        agent_id = str(getattr(adapter, "agent_id", "") or "")
        if not agent_id:
            continue
        if not adapter.is_connected():
            continue  # Push wäre nur Log-Lärm — nächsten Event nutzen
        for chat_id in _push_targets(adapter):
            chat_id = str(chat_id or "").strip()
            if not chat_id:
                continue
            key = (agent_id, chat_id)
            with _DEDUP_LOCK:
                previous = _LAST_PUSHED.get(key)
                if previous is not None and previous[0] == fingerprint:
                    continue
            try:
                await adapter.push_session_meta(
                    chat_id, platform=platform, model=model, sub_agents=subs)
            except Exception as exc:
                logger.warning(
                    "flipsi-session-meta: push_session_meta fehlgeschlagen "
                    "(agent=%s, chat=%s): %s", agent_id, chat_id[:24], exc)
                continue  # nicht dedupen — nächster Event versucht erneut
            with _DEDUP_LOCK:
                _LAST_PUSHED[key] = (fingerprint, time.monotonic())


async def handle(event_type: str, context: Any) -> None:
    """Hook-Entry (gateway/hooks.py: sync oder async, Fehler = Log-Zeile).
    Alles hier ist fail-soft: ein Hook-Fehler hält keinen Turn auf."""
    try:
        if not isinstance(context, dict):
            return
        await _observe(event_type, context)
    except Exception:
        logger.warning("flipsi-session-meta: Beobachtung fehlgeschlagen (event=%s)",
                       event_type, exc_info=True)
